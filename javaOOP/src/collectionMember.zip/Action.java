package 콜렉션멤버;

public interface Action {
	public void excute();
}
