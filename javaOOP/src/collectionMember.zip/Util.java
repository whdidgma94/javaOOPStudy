package 콜렉션멤버;

import java.util.Scanner;

public class Util {
	static Scanner scan = new Scanner(System.in);

}
